﻿AizenX Forge v2.2.1
Verified RDR2 Asset Pipeline

INSTALL
1. Extract this package to a normal folder.
2. Run AizenX.exe.
3. Requires Windows x64 and the .NET 10 Windows Desktop Runtime.
4. Install RDR2 Manifest Tool separately. If AizenX does not auto-detect RDR2YtdExporter.exe, set it in Settings.
5. Select your Red Dead Redemption 2 game folder if auto-detection does not find it.

CORE WORKFLOWS
- Export to XML: verified archive search + semantic XML where supported.
- Native fallback: unsupported semantic XML families can be preserved as native data instead of being falsely converted.
- Build from XML: rebuild supported resources and verify them before accepting output.
- Native YMT: accepts .ymt.xml and XML-text .ymt inputs; auto-detects supported RSC8 / PSO metadata paths.
- Search Assets: uses real RPF archive identities and supports raw hash searches.

VERIFICATION
The public build rejects unsafe/unverified rebuilds rather than intentionally writing known-bad output. See VERIFICATION.txt for the regression evidence used for this release.

THIRD PARTY
CodeX/Oodle/RDR2 Manifest Tool components are not bundled. See THIRD_PARTY_NOTICE.txt.
